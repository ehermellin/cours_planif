from math import floor

from mesa import Model
from mesa.datacollection import DataCollector
from mesa.space import MultiGrid
from mesa.time import RandomActivation

from agents import DummyRobot, PlannerRobot, RadioactiveZone, Waste, Robot
from agents.communication import MessageService


class WasteRobotModel(Model):

    def __init__(self, width, height,
                 n_waste_1=300, n_waste_2=10, n_waste_3=0,
                 n_robots_1=30, n_robots_2=20, n_robots_3=5,
                 ):

        super().__init__()

        self.schedule = RandomActivation(self)

        self.__messages_service = MessageService(self.schedule)
        # MessageService.get_instance().set_instant_delivery(False)

        self.grid = MultiGrid(width, height, torus=False)

        n_waste_per_zone = (n_waste_1, n_waste_2, n_waste_3)
        n_robots_per_zone = (n_robots_1, n_robots_2, n_robots_3)
        n_robots_total = sum(n_robots_per_zone)

        # Simple helper variable to keep track of unique id for every agent
        self.id = 0

        # Add the planner robot
        a = PlannerRobot(self.id, self, n_robots_total)
        self.schedule.add(a)
        self.id += 1

        # Choose the robot type
        RobotType = DummyRobot

        # Create radioactive zones
        for _, x, y in self.grid.coord_iter():
            a = RadioactiveZone(self.id, self, (x, y))
            self.schedule.add(a)
            self.grid.place_agent(a, a.pos)
            self.id += 1

        # Create waste in each zone
        for zone, n_waste in enumerate(n_waste_per_zone):
            for _ in range(n_waste):
                x = (self.random.random() + zone) * 1/3
                x = floor(x * self.grid.width)
                y = self.random.randrange(self.grid.height)
                a = Waste(self.id, self, (x, y), zone)
                self.schedule.add(a)
                self.grid.place_agent(a, a.pos)
                self.id += 1

        # Create robots in each zone
        for zone, n_robots in enumerate(n_robots_per_zone):
            for _ in range(n_robots):
                x_max = floor(self.grid.width / 3 * (zone + 1))
                x = self.random.randrange(x_max)
                y = self.random.randrange(self.grid.height)
                a = RobotType(self.id, self, (x, y), zone)
                self.schedule.add(a)
                self.grid.place_agent(a, a.pos)
                self.id += 1

        # Gather data
        model_reporters = dict(
            Waste_0=lambda m: stat_waste(m, [0]),
            Waste_1=lambda m: stat_waste(m, [1]),
            Waste_2=lambda m: stat_waste(m, [2]),
            Robot_0=lambda m: stat_robot(m, [0], n_robots_total),
            Robot_1=lambda m: stat_robot(m, [0, 1], n_robots_total),
            Robot_2=lambda m: stat_robot(m, [0, 1, 2], n_robots_total),
        )
        self.datacollector = DataCollector(model_reporters=model_reporters)

    def step(self):
        self.schedule.step()
        self.datacollector.collect(self)
        self.__messages_service.dispatch_messages()

    @property
    def messages_service(self):
        return self.__messages_service


def stat_waste(model, type_nb):
    '''Filter out the number of waste elements in the grid'''
    valid_agents = filter(
        lambda agent: isinstance(agent, Waste) and (agent.type in type_nb),
        model.schedule.agents
    )

    return len(list(valid_agents))


def stat_robot(model, type_nb, nb_total=1):
    '''
    Filter out the percentage of "active" robots (i.e. those carrying a
    waste to the disposal zone)
    '''

    valid_agents = filter(
        lambda agent: isinstance(agent, Robot) and (
            agent.type in type_nb) and agent.carrying_waste_to_dispose,
        model.schedule.agents
    )

    return len(list(valid_agents)) / nb_total


if __name__ == '__main__':

    model = WasteRobotModel(
        width=20,
        height=20,
        n_waste_1=300,
        n_robots_1=30,
        n_waste_2=10,
        n_robots_2=20,
        n_waste_3=0,
        n_robots_3=5,
    )

    for _ in range(10):
        model.step()
