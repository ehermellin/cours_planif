Malheureusement il y a un bug qui empêche le code de bien fonctionner* et je n’arrive pas à l’identifier à l’heure actuelle.

 

Pour la solution j’ai ajouté une action seek_waste qui doit se réaliser si un robot et un waste sont dans la même zone mais que le robot n’a pas encore connaissance du waste.

Ceci se traduit dans le MAS comme un robot qui ne voit pas dans son voisinage immédiat du waste, et l’instruction du seek_waste consiste en faire du random_move dans la zone jusqu’à le trouver.

 

Normalement les protocoles de communications et actions son « bien » implémentés et le « seul » challenge est le temps de planification.

En effet, même avec uniquement 3 robots et 3 waste, le temps est non négligeable !

 

Dans l’esprit de garder le MAS avec la planification, les DummyRobot ne font que suivre le planning du PlannerRobot jusqu’à ce qu’ils finissent leur tâche.

Et si un DummyRobot a finalisé avec la liste de taches lui correspondant, il communique au PlannerRobot.

Ensuite ce dernier prendra connaissance de la situation et proposera un autre plan.

Ainsi on ne devrait pas avoir des DummyRobots qui ne font rien !