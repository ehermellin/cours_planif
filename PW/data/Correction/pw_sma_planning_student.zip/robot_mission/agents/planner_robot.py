from planning import make_plan

from .communicating_robot import CommunicatingRobot
from .communication import Mailbox, MessagePerformative
from .robot import Robot
from .objects import Waste


class PlannerRobot(CommunicatingRobot):
    '''
    Implement Planner Robot class that creates and communicates the plan to
    other Robots.
    '''

    def __init__(self, unique_id, model, n_robots_total):
        super().__init__(unique_id, model, None, None)
        super().__init_mailbox__(f'ROBOT_{unique_id}', Mailbox(),
                                 self.model.messages_service)

        self.waste_info = None
        self.robots_info = None
        self.n_robots_total = n_robots_total
        self.plan = None

    def step(self):

        self.gather_waste_info()
        self.verify_messages()

        if self.robots_info is None:
            self.ask_robots_info()
            return

        elif self.plan is None:
            self.plan = make_plan(*self.waste_info, *self.robots_info)
            if self.plan is not None:
                self.send_robots_instructions()

    def dummy_robots(self) -> list:
        return list(filter(lambda c: (isinstance(c, Robot) and
                                      (not isinstance(c, self.__class__))),
                           self.model.schedule.agents))

    def ask_robots_info(self):
        for robot in self.dummy_robots():
            self.send_message(robot, MessagePerformative.QUERY_REF)

    def send_robots_instructions(self):
        robots = self.dummy_robots()
        for robot_id, robot_plan in self.plan.items():
            robot = next(filter(lambda r: r.unique_id == robot_id, robots))
            self.send_message(robot, MessagePerformative.PROPOSE, robot_plan)

    def verify_messages(self):

        messages = self.get_new_messages()
        if len(messages) == 0:
            return

        # the robot has mail !

        # first find if any robot has finished with the actions
        messages_priority = list(filter(
            lambda m: m.get_performative() == MessagePerformative.PROPOSE,
            messages
        ))

        if len(messages_priority) > 0:
            # it doesn't really matter how many message there are since
            # the queries are always the same

            # clear current plan (start planning again)
            self.robots_info = None
            self.plan = None
            return

        elif (len(messages)) == self.n_robots_total:
            robots_id = []
            robots_color = []
            robots_zone = []
            robots_near = []

            for message in messages:
                c = message.get_content()
                if c is not None:
                    robot_id, color, zone, waste_id = c
                    robots_id.append(robot_id)
                    robots_color.append(color)
                    robots_zone.append(zone)
                    robots_near.append((robot_id, waste_id))

            self.robots_info = (robots_id, robots_color,
                                robots_zone, robots_near)
        else:
            msg = 'Got {} messages from {} Robots, will wait for all messages'
            print(msg.format(len(messages), self.n_robots_total))
            self.robots_info is None
            return

    def gather_waste_info(self):

        wastes_id = []
        wastes_color = []
        wastes_zone = []

        wastes = filter(lambda c: isinstance(c, Waste),
                        self.model.schedule.agents)

        for waste in wastes:
            wastes_id.append(waste.unique_id)
            wastes_color.append(waste.type)
            wastes_zone.append(waste.current_zone())

        self.waste_info = (wastes_id, wastes_color, wastes_zone)
