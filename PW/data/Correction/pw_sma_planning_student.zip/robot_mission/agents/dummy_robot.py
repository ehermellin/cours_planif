from .communicating_robot import CommunicatingRobot
from .communication import MessagePerformative
from .planner_robot import PlannerRobot


class DummyRobot(CommunicatingRobot):
    '''
    Implement Dummy Robot class that does nothing unless told so by the
    Planner Robot
    '''

    def __init__(self, unique_id, model, pos, type):
        super().__init__(unique_id, model, pos, type)
        self.action_list = []

    def step(self):
        self.verify_messages()
        if self.action_list and len(self.action_list) > 0:
            self.execute_actions()
        else:
            self.move_randomly()

    def get_planner(self):
        return next(filter(lambda c: isinstance(c, PlannerRobot),
                           self.model.schedule.agents))

    def communicate_success(self):
        print(type(self.model))
        print(f'ROBOT_{self.unique_id} has finished !')
        planner = self.get_planner()
        self.send_message(planner, MessagePerformative.PROPOSE)

    def verify_messages(self):

        messages = self.get_new_messages()
        if len(messages) == 0:
            return

        # the robot has mail !

        # first find if the robot has been queried by the planner robot
        messages_priority = list(filter(
            lambda m: m.get_performative() == MessagePerformative.QUERY_REF,
            messages
        ))
        if len(messages_priority) > 0:
            # it doesn't really matter how many message there are since
            # the queries are always the same

            waste = self.waste_nearby()
            content = [self.unique_id, self.type, self.current_zone(),
                       waste.unique_id if waste else None]

            planner = self.get_planner()
            self.send_message(planner, MessagePerformative.INFORM_REF, content)
            # clear the action list and wait for instructions
            self.action_list = []

        # incorporate received instructions into the robot's action list
        if len(messages) > 0:
            self.action_list = messages[0].get_content()

    def execute_actions(self):
        action_name, args = self.action_list[0]
        print(f'ROBOT_{self.unique_id}', action_name, *args)
        execute_action = self.__getattribute__(f'action_{action_name}')
        execute_action(*args)

    def action_pickup(self, waste, zone):
        self.pick_waste(self.waste_nearby())
        self.action_completed()

    def action_drop(self, waste, zone):
        self.depose_waste()
        self.action_completed()

    def action_change_zone(self, zone1, zone2):
        self.move_to_zone(zone2)
        zone = self.current_zone()
        if zone == zone2:
            self.action_completed()

    def action_transform(self, waste, color1, color2):
        # NOTE: no need to perform any action as self.depose_waste()
        # does transform and drop actions
        self.action_completed()

    def action_seek_waste(self, waste, zone):
        self.move_to_zone(zone)
        if self.waste_nearby():
            self.action_completed()

    def action_completed(self):
        _ = self.action_list.pop(0)

        if len(self.action_list) == 0:
            # no more actions for this robot !
            # ask planner robot for new actions
            self.communicate_success()

    def move_to_zone(self, zone):
        orientation = zone - self.current_zone()

        if orientation != 0:
            self.move_to_disposal_site(0)
        else:
            self.move_randomly()
