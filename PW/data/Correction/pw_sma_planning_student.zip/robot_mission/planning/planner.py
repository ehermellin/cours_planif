import os
from collections import defaultdict

import pyplanning as pp

from .hostile import RadioactivityProblem


def make_plan(*args, **kwargs):

    here = os.path.normpath(os.path.dirname(__file__))
    domain_file = os.path.join(here, 'domain')
    problem_file = os.path.join(here, 'problem')

    p = RadioactivityProblem(*args, **kwargs)
    p.generate_domain_pddl(filename=domain_file)
    p.generate_problem_pddl(filename=problem_file)

    _, problem = pp.load_pddl(domain_file + '.pddl', problem_file + '.pddl')

    print('Start solving problem')
    heuristic = pp.solvers.heuristics.goals_remaining(problem)
    plan = pp.solvers.search_plan(problem, heuristic)
    print('Done solving problem')

    if plan is None:
        print('No valid plan found')
        return

    instructions = [(i.action.name, *i.objects) for i in plan]

    instructions_by_robot = defaultdict(lambda: [])
    for (action, robot, *args) in instructions:
        robot_id = str2int(robot)
        action_fcn = action.replace('-', '_')
        args = [str2int(arg) for arg in args]
        instructions_by_robot[robot_id].append((action_fcn, args))

    plan = dict(instructions_by_robot)

    print_plan(plan)
    return plan


def print_plan(plan):
    for r, a in plan.items():
        print('ROBOT', r)
        for b in a:
            print('-', *b)
        print()


def str2int(s: str) -> int:
    return int(''.join((c for c in s if c.isdigit())))


if __name__ == '__main__':

    wastes_id = [0, 1, 2]
    wastes_color = [0, 1, 2]
    wastes_zone = [0, 1, 1]

    robots_id = [10, 20, 30]
    robots_color = [0, 1, 2]
    robots_zone = [0, 0, 0]

    robot_waste_proximity = [(10, None), (20, None), (30, 2)]

    plan = make_plan(wastes_id, wastes_color, wastes_zone,
                     robots_id, robots_color, robots_zone,
                     robot_waste_proximity)
    print_plan(plan)
