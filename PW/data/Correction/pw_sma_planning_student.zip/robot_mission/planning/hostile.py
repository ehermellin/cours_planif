from py2pddl import Domain, action, create_type, goal, init, predicate
from random import randint


class RadioactivityDomain(Domain):

    Wastes = create_type('Wastes')
    Robots = create_type('Robots')
    Zones = create_type('Zones')
    Colors = create_type('Colors')

    @predicate(Robots, Zones)
    def allowed_in_zone(se, robot, zone):
        pass

    @predicate(Robots, Colors, Colors)
    def robot_target(self, robot, color1, color2):
        pass

    @predicate(Wastes, Zones)
    def waste_in_zone(self, waste, zone):
        pass

    @predicate(Wastes, Robots)
    def waste_in_robot(self, waste, robot):
        pass

    @predicate(Wastes, Robots)
    def waste_near(self, waste, robot):
        pass

    @predicate(Robots, Zones)
    def robot_in_zone(self, robot, zone):
        pass

    @predicate(Wastes, Colors)
    def waste_color(self, waste, color):
        pass

    @action(Robots, Wastes, Zones)
    def pickup(self, robot, waste, zone):
        precond: list = [
            self.waste_in_zone(waste, zone),
            self.robot_in_zone(robot, zone),
            self.waste_near(waste, robot),
        ]
        effect: list = [
            ~self.waste_in_zone(waste, zone),
            self.waste_in_robot(waste, robot),
            ~self.waste_near(waste, robot),
        ]
        return precond, effect

    @action(Robots, Wastes, Zones)
    def drop(self, robot, waste, zone):
        precond: list = [
            self.robot_in_zone(robot, zone),
            self.waste_in_robot(waste, robot),
        ]
        effect: list = [
            self.waste_in_zone(waste, zone),
            ~self.waste_in_robot(waste, robot),
        ]
        return precond, effect

    @action(Robots, Zones, Zones)
    def change_zone(self, robot, zone1, zone2):
        precond: list = [
            self.robot_in_zone(robot, zone1),
            self.allowed_in_zone(robot, zone2),
        ]
        effect: list = [
            ~self.robot_in_zone(robot, zone1),
            self.robot_in_zone(robot, zone2),
        ]
        return precond, effect

    @action(Robots, Wastes, Colors, Colors)
    def transform(self, robot, waste, color1, color2):
        precond: list = [
            self.waste_in_robot(waste, robot),
            self.waste_color(waste, color1),
            self.robot_target(robot, color1, color2),
        ]
        effect: list = [
            self.waste_color(waste, color2),
            ~self.waste_color(waste, color1),
        ]
        return precond, effect

    @action(Robots, Wastes, Zones)
    def seek_waste(self, robot, waste, zone):
        precond: list = [
            self.waste_in_zone(waste, zone),
            self.robot_in_zone(robot, zone),
        ]
        effect: list = [
            self.waste_near(waste, robot),
            # NOTE: these two are dummy effects so that py2pddl generates an
            # Effect with AND condition (which is a requirement for pyplanning)
            self.waste_in_zone(waste, zone),
            self.robot_in_zone(robot, zone),
        ]
        return precond, effect


class RadioactivityProblem(RadioactivityDomain):

    def __init__(self, wastes_id, wastes_color, wastes_zone,
                 robots_id, robots_color, robots_zone,
                 robot_waste_proximity):
        super().__init__()

        # NOTE: this user-created attributes are not meant to be written as
        # objects in the problem.pddl file. hence they must be "hidden" or
        # py2pddl will include them !
        self.__wastes_id = wastes_id
        self.__wastes_color = wastes_color
        self.__wastes_zone = wastes_zone

        self.__robots_id = robots_id
        self.__robots_color = robots_color
        self.__robots_zone = robots_zone

        self.__robot_waste_proximity = robot_waste_proximity

        Wastes = RadioactivityDomain.Wastes
        Robots = RadioactivityDomain.Robots
        Colors = RadioactivityDomain.Colors
        Zones = RadioactivityDomain.Zones

        self.wastes = Wastes.create_objs(self.__wastes_id, prefix='waste')
        self.robots = Robots.create_objs(self.__robots_id, prefix='robot')
        self.colors = Colors.create_objs([0, 1, 2], prefix='color')
        self.zones = Zones.create_objs([0, 1, 2, 3], prefix='zone')

    @init
    def init(self) -> list:

        robot_permissions = []
        robot_positions = []
        robot_tasks = []
        near_conditions = []
        waste_positions = []
        waste_colors = []

        for id, color, zone in zip(self.__robots_id,
                                   self.__robots_color,
                                   self.__robots_zone):

            robot = self.robots[id]

            robot_positions.append(self.robot_in_zone(robot, self.zones[zone]))

            if color == 0:
                robot_permissions.append(self.allowed_in_zone(robot,
                                                              self.zones[0]))
                robot_tasks.append(self.robot_target(robot,
                                                     self.colors[0],
                                                     self.colors[1]))
            elif color == 1:
                robot_permissions.extend((
                    self.allowed_in_zone(robot, self.zones[0]),
                    self.allowed_in_zone(robot, self.zones[1])))
                robot_tasks.append(self.robot_target(robot,
                                                     self.colors[1],
                                                     self.colors[2]))
            elif color == 2:
                robot_permissions.extend((
                    self.allowed_in_zone(robot, self.zones[0]),
                    self.allowed_in_zone(robot, self.zones[1]),
                    self.allowed_in_zone(robot, self.zones[2]),
                    self.allowed_in_zone(robot, self.zones[3])))

        for id, color, zone in zip(self.__wastes_id,
                                   self.__wastes_color,
                                   self.__wastes_zone):

            waste = self.wastes[id]
            waste_positions.append(self.waste_in_zone(waste, self.zones[zone]))
            waste_colors.append(self.waste_color(waste, self.colors[color]))

        for robot_id, waste_id, in self.__robot_waste_proximity:
            robot = self.robots[robot_id]
            for id in self.__wastes_id:
                waste = self.wastes[id]
                if id == waste_id:
                    near_conditions.append(self.waste_near(waste, robot))

        robot_init = robot_permissions + robot_positions + robot_tasks
        waste_init = waste_positions + waste_colors

        return robot_init + waste_init + near_conditions

    @goal
    def goal(self) -> list:
        move_to_zone = [
            self.waste_in_zone(self.wastes[id], self.zones[3])
            for id in self.__wastes_id
        ]
        convert_to_red = [
            self.waste_color(self.wastes[id], self.colors[2])
            for id in self.__wastes_id
        ]
        return move_to_zone + convert_to_red
