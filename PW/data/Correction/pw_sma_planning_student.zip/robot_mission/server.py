from mesa.visualization.ModularVisualization import ModularServer
from mesa.visualization.modules import CanvasGrid, ChartModule
from mesa.visualization.UserParam import UserSettableParameter

from model import WasteRobotModel


def text(display_text):
    return UserSettableParameter('static_text', value=display_text)


def param(display_text, value):
    return UserSettableParameter('number', display_text, value=value)


if __name__ == '__main__':

    width = 7
    height = 7

    info_1 = text('1st zone')
    n_waste_1 = param('Waste', 1)
    n_robots_1 = param('Robots', 1)

    info_2 = text('2nd zone')
    n_waste_2 = param('Waste', 1)
    n_robots_2 = param('Robots', 1)

    info_3 = text('3rd zone')
    n_waste_3 = param('Waste', 1)
    n_robots_3 = param('Robots', 1)

    canvas_element = CanvasGrid(lambda a: a.potrayal, width, height, 500, 500)

    chart_element_1 = ChartModule([
        dict(Label='Robot_0', Color='#2a6a9b'),
        dict(Label='Robot_1', Color='#debd57'),
        dict(Label='Robot_2', Color='#b63232'),
    ])

    chart_element_2 = ChartModule([
        dict(Label='Waste_0', Color='#95bcdf'),
        dict(Label='Waste_1', Color='#edcc4c'),
        dict(Label='Waste_2', Color='#ff1933'),
    ])

    server = ModularServer(
        WasteRobotModel,
        [canvas_element, chart_element_1, chart_element_2],
        'Waste & Robot Model',
        dict(
            width=width,
            height=height,
            info_1=info_1,
            n_waste_1=n_waste_1,
            n_robots_1=n_robots_1,
            info_2=info_2,
            n_waste_2=n_waste_2,
            n_robots_2=n_robots_2,
            info_3=info_3,
            n_waste_3=n_waste_3,
            n_robots_3=n_robots_3,
        ),
    )
    server.port = 8521
    server.launch()
