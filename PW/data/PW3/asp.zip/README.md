**ASP tutorial**
-------------

## Dependencies

Java JDK 8 must be installed on the computer :

**On Windows**

Go to Oracle website and download the JDK corresponding to your computer architecture (x64 or x86): [Java](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)

After the installation, you have to add java in the *PATH*.

**On Linux (Debian / Ubuntu)**

    sudo apt-get install openjdk-8-jdk

## Build / Run ASP

Download the jar from release folder or clone the repository.

With Gradle (if cloned):

    # Build Server (compile, assemble, jar, checkstyle, spotbugs)
    ./gradlew build
    # Generate .jar file
    ./gradlew jar
    # Generate javadoc
    ./gradlew javadoc
    # Run Server
    ./gradlew run -PArgs=args1,args2,args3,...

With java command lines:

    java -jar asp-<version>.jar args1 args2 args3 ...
	
Arguments: