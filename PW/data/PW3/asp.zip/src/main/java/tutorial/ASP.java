package tutorial;

import fr.uga.pddl4j.encoding.CodedProblem;
import fr.uga.pddl4j.planners.statespace.AbstractStateSpacePlanner;
import fr.uga.pddl4j.util.Plan;

import java.util.Properties;

/**
 * This class implements a simple forward planner based on A* algorithm.
 *
 * @author E. Hermellin
 * @version 1.0 - 11.09.2020
 */
public class ASP extends AbstractStateSpacePlanner {

    /*
     * The arguments of the planner.
     */
    private Properties arguments;

    /**
     * Creates a new ASP planner with the default parameters.
     *
     * @param arguments the arguments of the planner.
     */
    public ASP(final Properties arguments) {
        super();
        this.arguments = arguments;
    }

    /**
     * Solves the planning problem and returns the first solution search found.
     *
     * @param problem the problem to be solved.
     * @return a solution search or null if it does not exist.
     */
    @Override
    public Plan search(final CodedProblem problem) {
        // To be completed
        return null;
    }

    /**
     * The main method of the ASP example. The command line syntax is as follow:
     * OPTIONS   DESCRIPTIONS
     * -o str   operator file name
     * -f str   fact file name
     * -w num   the weight used in the a star search (preset: 1)
     * -t num   specifies the maximum CPU-time in seconds (preset: 300)
     * -h       print this message
     *
     * @param args the arguments of the command line.
     */
    public static void main(String[] args) {
        System.out.println("Hello ASP!");
    }
}