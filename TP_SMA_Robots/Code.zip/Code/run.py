from robot_mission.server import server

server.launch()
