#from mesa import Agent
from communication.agent.CommunicatingAgent import CommunicatingAgent

class Radioactivity(CommunicatingAgent):
    def __init__(self, unique_id, model, pos, level):
        super().__init__(unique_id, model, "Radioactivity {}".format(unique_id))
        self.pos = pos
        self.level = level

    def step(self):
        pass


class DisposalZone(CommunicatingAgent):
    def __init__(self, unique_id, model, pos):
        super().__init__(unique_id, model, "DisposalZone {}".format(unique_id))
        self.pos = pos

    def step(self):
        pass
        

class Waste(CommunicatingAgent):
    def __init__(self, unique_id, model, name, pos, color):
        super().__init__(unique_id, model, "{} {}".format(name, unique_id))
        self.color = color
        self.pos = pos
        self.carried = False

    def step(self):
        pass

class WhiteWaste(Waste):
    def __init__(self, unique_id, model, pos):
        super().__init__(unique_id, model, "WhiteWaste", pos, "white")

class YellowWaste(Waste):
    def __init__(self, unique_id, model, pos):
        super().__init__(unique_id, model, "YellowWaste", pos, "yellow")

class RedWaste(Waste):
    def __init__(self, unique_id, model, pos):
        super().__init__(unique_id, model, "RedWaste", pos, "red")
