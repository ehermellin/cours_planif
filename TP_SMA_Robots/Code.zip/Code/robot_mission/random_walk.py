"""
Generalized behavior for random walking, one grid cell at a time.
"""

from communication.agent.CommunicatingAgent import CommunicatingAgent

from robot_mission.objects import Radioactivity, Waste


class RandomWalker(CommunicatingAgent):
    """
    Class implementing random walker methods in a generalized manner.
    """

    grid = None
    x = None
    y = None
    moore = True

    def __init__(self, unique_id, name, pos, model, moore=True, max_level = 1):
        """
        grid: The MultiGrid object in which the agent lives.
        x: The agent's current x coordinate
        y: The agent's current y coordinate
        moore: If True, may move in all 8 directions.
                Otherwise, only up, down, left, right.
        """
        super().__init__(unique_id, model, "{} {}".format(name, unique_id))
        self.pos = pos
        self.moore = moore
        self.max_level = max_level

    def can_move_to_pos(self, pos, initial_pos):
        initial_cell = self.model.grid.get_cell_list_contents([initial_pos])
        cell = self.model.grid.get_cell_list_contents([pos])

        initial_radioactivity = [a for a in initial_cell if isinstance(a, Radioactivity)]
        radioactivity = [a for a in cell if isinstance(a, Radioactivity)]
        if len(radioactivity) == 0:
            return False

        robots = [a for a in cell if isinstance(a, RandomWalker)]
        if len(robots) > 0:
            return False
        
        if len(initial_radioactivity) == 0:
            return radioactivity[0].level == self.max_level

        if initial_radioactivity[0].level < self.max_level:
            return initial_pos[0] == pos[0] or radioactivity[0].level == self.max_level

        return radioactivity[0].level <= self.max_level

    def random_move(self):
        """
        Step one cell in any allowable direction.
        """
        # Pick the next cell from the adjacent cells.
        next_moves = self.model.grid.get_neighborhood(self.pos, self.moore, False)
        next_allowed_moves = [pos for pos in next_moves if self.can_move_to_pos(pos, self.pos)]
        next_move = self.random.choice(next_allowed_moves)
        # Now move:
        self.model.grid.move_agent(self, next_move)
