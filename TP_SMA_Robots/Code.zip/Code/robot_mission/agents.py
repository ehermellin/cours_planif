from communication.message.Message import Message
from communication.message.MessagePerformative import MessagePerformative

from robot_mission.random_walk import RandomWalker
from robot_mission.objects import DisposalZone, RedWaste, Radioactivity, Waste, WhiteWaste, YellowWaste

levels = {
    "white": 1,
    "yellow": 2,
    "red": 3
}
next_colors = {
    "white": "yellow",
    "yellow": "red",
    "red": None
}
Wastes = {
    "white": WhiteWaste,
    "yellow": YellowWaste,
    "red": RedWaste
}

class Robot(RandomWalker):
    def __init__(self, unique_id, model, name, pos, color):
        max_level = levels[color]
        super().__init__(unique_id, name, pos, model, model.moore, max_level)
        self.carried_wastes = []
        self.color = color
        self.max_level = max_level
        self.next_color = next_colors[color]

    def can_carry_waste(self, waste):
        return waste.color == self.color and not waste.carried

    def carry_waste(self, waste):
        self.carried_wastes.append(waste)
        waste.carried = True

    def release_wastes(self, pos):
        for waste in self.carried_wastes:
            waste.carried = False
            self.model.schedule.remove(waste)
            self.model.grid.remove_agent(waste)
        self.carried_wastes.clear()

        if self.next_color is not None:
            ColorWaste = Wastes[self.next_color]
            a = ColorWaste(self.model.next_id(), self.model, pos)
            self.model.schedule.add(a)
            self.model.grid.place_agent(a, pos)

            other_robots = [a for a in self.model.schedule.agents if isinstance(a, Robot)]
            next_robots = [r for r in other_robots if r.color == self.next_color]
            for other_robot in next_robots:
                self.send_message(
                    Message(self.get_name(), other_robot.get_name(), MessagePerformative.INFORM_REF, pos)
                )

    def move_with_wastes(self, pos):
        self.model.grid.move_agent(self, pos)
        for waste in self.carried_wastes:
            self.model.grid.move_agent(waste, pos)

    def random_move_with_wastes(self):
        self.random_move()
        for waste in self.carried_wastes:
            # to check
            self.model.grid.move_agent(waste, self.pos)

    def look_for_wastes(self):
        self.random_move_with_wastes()
        cell = self.model.grid.get_cell_list_contents([self.pos])
        wastes = [a for a in cell if isinstance(a, Waste) and self.can_carry_waste(a)]
        if len(wastes) > 0:
            waste = self.random.choice(wastes)
            self.carry_waste(waste)

    def read_messages(self):
        list_messages = self.get_new_messages()
        for message in list_messages:
            print(message)


class WhiteRobot(Robot):
    def __init__(self, unique_id, model, pos):
        super().__init__(unique_id, model, "WhiteRobot", pos, "white")

    def step(self):
        super().step()
        has_moved = False

        if len(self.carried_wastes) < 2:
            self.look_for_wastes()
            has_moved = True

        if len(self.carried_wastes) == 2:
            x, y = self.pos
            cell = self.model.grid.get_cell_list_contents([(x + 1, y)])
            radioactivity = [a for a in cell if isinstance(a, Radioactivity)]
            if len(radioactivity) > 0 and radioactivity[0].level > self.max_level:
                self.release_wastes((x, y))
            elif not has_moved:
                self.move_with_wastes((x + 1, y))
                next_cell = self.model.grid.get_cell_list_contents([(x + 2, y)])
                next_radioactivity = [a for a in next_cell if isinstance(a, Radioactivity)]
                if len(next_radioactivity) > 0 and next_radioactivity[0].level > self.max_level:
                    self.release_wastes((x + 1, y))


class YellowRobot(Robot):
    def __init__(self, unique_id, model, pos):
        super().__init__(unique_id, model, "YellowRobot", pos, "yellow")

    def step(self):
        super().step()
        has_moved = False

        self.read_messages()

        if len(self.carried_wastes) < 2:
            self.look_for_wastes()
            has_moved = True

        if len(self.carried_wastes) == 2:
            x, y = self.pos
            cell = self.model.grid.get_cell_list_contents([(x + 1, y)])
            radioactivity = [a for a in cell if isinstance(a, Radioactivity)]
            if len(radioactivity) > 0 and radioactivity[0].level > self.max_level:
                self.release_wastes((x, y))
            elif not has_moved:
                self.move_with_wastes((x + 1, y))
                next_cell = self.model.grid.get_cell_list_contents([(x + 2, y)])
                next_radioactivity = [a for a in next_cell if isinstance(a, Radioactivity)]
                if len(next_radioactivity) > 0 and next_radioactivity[0].level > self.max_level:
                    self.release_wastes((x + 1, y))


class RedRobot(Robot):
    def __init__(self, unique_id, model, pos):
        super().__init__(unique_id, model, "RedRobot", pos, "red")

    def step(self):
        super().step()
        has_moved = False

        if len(self.carried_wastes) < 1:
            self.look_for_wastes()
            has_moved = True

        if len(self.carried_wastes) == 1:
            x, y = self.pos
            cell = self.model.grid.get_cell_list_contents([(x, y)])
            disposal_zone = [a for a in cell if isinstance(a, DisposalZone)]
            if len(disposal_zone) > 0:
                self.release_wastes((x, y))
            elif not has_moved:
                self.move_with_wastes((x + 1, y))
                next_cell = self.model.grid.get_cell_list_contents([(x + 1, y)])
                next_disposal_zone = [a for a in next_cell if isinstance(a, DisposalZone)]
                if len(next_disposal_zone) > 0:
                    self.release_wastes((x + 1, y))
