from mesa import Model
from mesa.space import MultiGrid
from mesa.datacollection import DataCollector
from communication.message.MessageService import MessageService

from robot_mission.agents import RedRobot, WhiteRobot, YellowRobot
from robot_mission.objects import DisposalZone, Radioactivity, RedWaste, WhiteWaste, YellowWaste
from robot_mission.schedule import RandomActivationByKind

class RobotModel(Model):
    def __init__(self, 
        width = 31, 
        height = 10, 
        z1_width = 10,
        z2_width = 10,
        initial_white_wastes = 16,
        initial_yellow_wastes = 8,
        initial_red_wastes = 4,
        initial_white_robots = 5,
        initial_yellow_robots = 5,
        initial_red_robots = 5
    ):
        super().__init__()
        self.moore = True
        self.schedule = RandomActivationByKind(self)
        self.__messages_service = MessageService(self.schedule)
        MessageService.get_instance().set_instant_delivery(False)
        self.grid = MultiGrid(width, height, False)
        self.datacollector = DataCollector(
            {
                "WhiteWaste": lambda m: m.schedule.get_kind_count(WhiteWaste),
                "YellowWaste": lambda m: m.schedule.get_kind_count(YellowWaste),
                "RedWaste": lambda m: m.schedule.get_kind_count(RedWaste),
                "WhiteWaste_carried": lambda m: m.schedule.get_carried_wastes_count(WhiteWaste),
                "YellowWaste_carried": lambda m: m.schedule.get_carried_wastes_count(YellowWaste),
                "RedWaste_carried": lambda m: m.schedule.get_carried_wastes_count(RedWaste),
            }
        )

        # Radioactivity
        z1_grid = MultiGrid(z1_width, height, False)
        for _, x, y in z1_grid.coord_iter():
            a = Radioactivity(self.next_id(), self, (x, y), 1)
            self.schedule.add(a)
            self.grid.place_agent(a, (x, y))

        z2_width_offset = z1_width
        z2_grid = MultiGrid(z2_width, height, False)
        for _, x, y in z2_grid.coord_iter():
            a = Radioactivity(self.next_id(), self, (x + z2_width_offset, y), 2)
            self.schedule.add(a)
            self.grid.place_agent(a, (x + z2_width_offset, y))

        z3_width = width - z1_width - z2_width - 1
        z3_width_offset = z1_width + z2_width
        z3_grid = MultiGrid(z3_width, height, False)
        for _, x, y in z3_grid.coord_iter():
            a = Radioactivity(self.next_id(), self, (x + z3_width_offset, y), 3)
            self.schedule.add(a)
            self.grid.place_agent(a, (x + z3_width_offset, y))
        
        # Disposal zone
        disposal_offset = z1_width + z2_width + z3_width
        disposal_grid = MultiGrid(1, height, False)
        for _, x, y in disposal_grid.coord_iter():
            a = DisposalZone(self.next_id(), self, (x + disposal_offset, y))
            self.schedule.add(a)
            self.grid.place_agent(a, (x + disposal_offset, y))

        # Wastes
        for i in range(initial_white_wastes):
            x = self.random.randrange(0, z1_width)
            y = self.random.randrange(height)
            a = WhiteWaste(self.next_id(), self, (x, y))
            self.schedule.add(a)
            self.grid.place_agent(a, (x, y))

        for i in range(initial_yellow_wastes):
            x = self.random.randrange(z2_width_offset, z2_width_offset + z2_width)
            y = self.random.randrange(height)
            a = YellowWaste(self.next_id(), self, (x, y))
            self.schedule.add(a)
            self.grid.place_agent(a, (x, y))

        for i in range(initial_red_wastes):
            x = self.random.randrange(z3_width_offset, z3_width_offset + z3_width)
            y = self.random.randrange(height)
            a = RedWaste(self.next_id(), self, (x, y))
            self.schedule.add(a)
            self.grid.place_agent(a, (x, y))

        # Robots
        for i in range(initial_white_robots):
            x = self.random.randrange(0, z1_width)
            y = self.random.randrange(height)
            a = WhiteRobot(self.next_id(), self, (x, y))
            self.schedule.add(a)
            self.grid.place_agent(a, (x, y))

        for i in range(initial_yellow_robots):
            x = self.random.randrange(z2_width_offset, z2_width_offset + z2_width)
            y = self.random.randrange(height)
            a = YellowRobot(self.next_id(), self, (x, y))
            self.schedule.add(a)
            self.grid.place_agent(a, (x, y))

        for i in range(initial_red_robots):
            x = self.random.randrange(z3_width_offset, z3_width_offset + z3_width)
            y = self.random.randrange(height)
            a = RedRobot(self.next_id(), self, (x, y))
            self.schedule.add(a)
            self.grid.place_agent(a, (x, y))

        self.running = True #new à ajouter.
        self.datacollector.collect(self)

    def step(self):
        self.__messages_service.dispatch_messages()
        self.schedule.step()
        self.datacollector.collect(self)