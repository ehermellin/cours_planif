from mesa.visualization.modules import CanvasGrid
from mesa.visualization.ModularVisualization import ModularServer
from mesa.visualization.modules import ChartModule
from mesa.visualization.UserParam import UserSettableParameter

from robot_mission.agents import Robot
from robot_mission.objects import DisposalZone, Radioactivity, Waste
from robot_mission.model import RobotModel

def get_radioactivity_color(agent):
    colors = {
        1: "white",
        2: "yellow",
        3: "red"
    }
    return colors[agent.level]

def get_waste_color(agent):
    colors = {
        "white": "whitesmoke",
        "yellow": "gold",
        "red": "darkred"
    }
    return colors[agent.color]

def get_robot_color(agent):
    colors = {
        "white": "whitesmoke",
        "yellow": "gold",
        "red": "darkred"
    }
    color = colors[agent.color]
    
    if len(agent.carried_wastes) == 0:
        return [color] + ["lightsteelblue" for i in range(4)]
    elif len(agent.carried_wastes) == 1:
        if agent.color == "red":
            return color
        else:
            return [color for i in range(2)] + ["lightsteelblue" for i in range(3)]
    else:
        return color

def agent_portrayal(agent):
    portrayal = {}

    if isinstance(agent, Radioactivity):
        portrayal = {
            "Shape": "rect",
            "Filled": "true",
            "w": 1,
            "h": 1,
            "Color": get_radioactivity_color(agent),
            "Layer": 0
        }

    if isinstance(agent, DisposalZone):
        portrayal = {
            "Shape": "rect",
            "Filled": "true",
            "w": 1,
            "h": 1,
            "Color": "darkgrey",
            "Layer": 0
        }

    if isinstance(agent, Waste):
        portrayal = {
            "Shape": "circle",
            "Filled": "true",
            "r": 0.5,
            "Color": get_waste_color(agent),
            "Layer": 1
        }

    if isinstance(agent, Robot):
        portrayal = {
            "Shape": "rect",
            "Filled": "true",
            "w": 0.5,
            "h": 0.5,
            "Color": get_robot_color(agent),
            "Layer": 2
        }

    return portrayal


grid = CanvasGrid(agent_portrayal, 31, 10, 620, 200)

chart1 = ChartModule([
    {"Label": "WhiteWaste", "Color": "whitesmoke"}, 
    {"Label": "YellowWaste", "Color": "yellow"},
    {"Label": "RedWaste", "Color": "red"},
])

chart2 = ChartModule([
    {"Label": "WhiteWaste_carried", "Color": "whitesmoke"}, 
    {"Label": "YellowWaste_carried", "Color": "yellow"}, 
    {"Label": "RedWaste_carried", "Color": "red"}, 
])

server = ModularServer(RobotModel,
                       [grid, chart1, chart2],
                       "Robot Model",
                       {
                           "initial_white_wastes": UserSettableParameter("slider", "Initial white wastes", 16, 1, 60, 1),
                           "initial_yellow_wastes": UserSettableParameter("slider", "Initial yellow wastes", 8, 1, 60, 1),
                           "initial_red_wastes": UserSettableParameter("slider", "Initial red wastes", 4, 1, 60, 1),
                           "initial_white_robots": UserSettableParameter("slider", "Initial white robots", 5, 1, 60, 1),
                           "initial_yellow_robots": UserSettableParameter("slider", "Initial yellow robots", 5, 1, 60, 1),
                           "initial_red_robots": UserSettableParameter("slider", "Initial red robots", 5, 1, 60, 1),
                       })
                       
server.port = 8522 # The default