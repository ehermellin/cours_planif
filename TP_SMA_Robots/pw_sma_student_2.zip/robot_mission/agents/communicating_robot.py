from math import floor

from .communication import (CommunicatingAgent, Mailbox, Message,
                            MessagePerformative)
from .objects import RadioactiveZone
from .robot import Robot


class CommunicatingRobot(CommunicatingAgent, Robot):
    '''
    Endow communicating capabilities to Robots so that simple messages
    are sent.  When a robot has disposed any new waste, it broadcasts
    it to any nearby robot. If the receiving robot is not concerned by
    the waste type, it simply relays the message to any nearby robot
    (the process repeats). However, if the receiving robot is actually
    concerned by the waste type, it moves towards the zone. Once it
    reaches the correct zone, it transitions to a Random Walker.

    NOTE: This process is sub-optimal as it does not guarantee that the
    message is quickly relayed to the target robots.

    NOTE: This process does respect the principles of MAS as the robots
    do not inform the actual position in their message but just that a
    waste of a certain type was deposed.

    NOTE: The concerned robots only move to the waste zone, however they
    do not know the exact position for the waste. However, given that the
    messages are expected to not travel much farther away from the frontier,
    it is safe to assume that the Random Walker behavior should suffice for
    the robot to find the waste.
    '''

    def __init__(self, unique_id, model, pos, type):
        super().__init__(unique_id, model, pos, type)
        super().__init_mailbox__(f'ROBOT_{unique_id}', Mailbox(),
                                 self.model.messages_service)

        self.wants_to_broadcast_message = False
        self.was_told_to_pick_waste = False

    @property
    def potrayal(self):
        p = super().potrayal
        # p['Color'] = 'yellow'
        # if self.wants_to_broadcast_message:
        #     p['Color'] = 'red'
        # if self.was_told_to_pick_waste:
        #     p['Color'] = 'blue'
        return p

    def step(self):

        # pick any waste present in the current cell
        if not self.carrying_waste_to_dispose:
            w = self.waste_nearby()
            if w is not None:
                self.pick_waste(w)

        # this loop needs to be separate in case the robot had picked-up waste
        if self.carrying_waste_to_dispose:
            self.move_to_disposal_site()
            if self.reached_disposal_site():
                self.depose_waste()
        else:
            # adapt behavior according to messages received
            self.verify_messages()

            if self.was_told_to_pick_waste:

                # decide wether to go east or west to pick up waste
                orientation = self.get_orientation_towards_waste()
                self.move_to_disposal_site(orientation)

            else:
                # the robot has a message to pass to any nearby robot
                if self.wants_to_broadcast_message:
                    m = self.talk_to_nearby_robot()
                    if m:
                        self.wants_to_broadcast_message = False
                self.move_randomly()

    def depose_waste(self):
        '''extend base method for added functionability'''
        super().depose_waste()
        self.wants_to_broadcast_message = True
        self.was_told_to_pick_waste = False

    def send_message(self, dest, performative):
        '''
        extend base method for ease of use

        NOTE: the message content is not used here, the robot's actions
        are determined by the performative
        '''
        # print(f'{self.get_name()} -> {dest.get_name()} [{performative}]')

        super().send_message(Message(
            from_agent=self.get_name(),
            to_agent=dest.get_name(),
            message_performative=performative,
            content=None,
        ))

    def talk_to_nearby_robot(self) -> bool:

        # get nearby robots regardless of their type
        nearby_robots = list(filter(
            lambda neighbor: isinstance(neighbor, self.__class__),
            self.model.grid.get_neighbors(self.pos, moore=True,
                                          include_center=False)
        ))

        # there is no robot to whom send the message to
        if len(nearby_robots) == 0:
            # no message was sent
            return False

        # first try to filter robots capables of handling the waste
        capable_robots = list(filter(
            lambda robot: robot.type == self.type + 1,
            nearby_robots))

        if len(capable_robots) > 0:
            # a robot is available, task it with picking up the wast
            nearby_robot = self.random.choice(capable_robots)
            self.send_message(nearby_robot, MessagePerformative.PROPOSE)

        else:
            # no available robot to handle the wast
            # try to simply relay the message to any robot
            nearby_robot = self.random.choice(nearby_robots)
            self.send_message(nearby_robot, MessagePerformative.INFORM_REF)

        # a message was sent
        return True

    def verify_messages(self):

        messages = self.get_new_messages()
        if len(messages) == 0:
            return

        # the robot has mail !

        # first find if the robot has been tasked with picking up waste
        messages_priority = list(filter(
            lambda m: m.get_performative() == MessagePerformative.PROPOSE,
            messages
        ))
        if len(messages_priority) > 0:
            # it doesn't really matter how many message there are since
            # the robot has to go the same place
            self.was_told_to_pick_waste = True

        # only informative messages are found, the robot will try to
        # broadcast the message as if it was the one who deposed the
        # waste
        self.wants_to_broadcast_message = True

    def get_orientation_towards_waste(self) -> int:
        '''propose either east/west direction'''

        # figure out the current zone by looking at the radiation level
        radio_agent = next(filter(
            lambda content: isinstance(content, RadioactiveZone),
            self.model.grid.get_cell_list_contents([self.pos])))
        zone = floor(radio_agent.radio_level)
        return -1 if (zone >= self.type) else 1
