from math import floor

from mesa import Agent


class SilentAgent(Agent):
    def __init__(self, unique_id, model, name=''):
        """
        The following dummy attributes and methods are required for the
        MessageService, which queries them for all agents in the schedule
        """
        super().__init__(unique_id, model)
        self.__name = name

    def get_name(self):
        return self.__name

    def set_name(self, name):
        self.__name = name


class Waste(SilentAgent):

    def __init__(self, unique_id, model, pos, type):
        super().__init__(unique_id, model)
        self.pos = pos
        self.type = type

    @property
    def potrayal(self):
        colors = ['#95bcdf', '#edcc4c', '#ff1933', '#000000']
        return dict(Shape='rect', Filled='true', Layer=1,
                    w=0.5, h=1, Color=colors[self.type])


class RadioactiveZone(SilentAgent):

    def __init__(self, unique_id, model, pos):
        super().__init__(unique_id, model)
        self.pos = pos

        x_rel = pos[0] / self.model.grid.width
        y_rel = pos[1] / self.model.grid.height

        if (x_rel > 0.9) and (y_rel > 0.9):
            self.zone = 3
            self.radio_level = 2
        else:
            self.zone = floor(x_rel * 3)
            self.radio_level = self.random.random() + self.zone

        self.set_name(f'RADIOACTIVE_ZONE_{self.zone}')

    @property
    def potrayal(self):
        p = int(self.radio_level / 3 * 0.5 * 255)
        if self.zone == 0:
            type = '#%02x%02x%02x' % (255 - p, 255, 255 - p)
        elif self.zone == 1:
            type = '#%02x%02x%02x' % (255 - p, 255 - p, 255)
        elif self.zone == 2:
            type = '#%02x%02x%02x' % (255, 255 - p, 255 - p)
        else:
            type = '#ffd352'

        return dict(Shape='rect', Filled='true', Layer=0,
                    w=1, h=1, Color=type)
