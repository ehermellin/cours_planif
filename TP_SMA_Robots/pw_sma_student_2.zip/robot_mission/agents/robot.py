from typing import Union

from mesa import Agent

from .objects import RadioactiveZone, Waste


class Robot(Agent):
    '''
    Implement basic Robot class that roams around the space trying to
    pick waste convert it and dispose it.
    '''

    def __init__(self, unique_id, model, pos, type):

        super().__init__(unique_id, model)

        self.pos = pos
        self.type = type

        self.carry = 0

    @property
    def potrayal(self):
        colors = ['#2a6a9b', '#debd57', '#b63232']
        size = 0.50 + self.carry * 0.1
        return dict(Shape='circle', Filled='true', Layer=2,
                    r=size, Color=colors[self.type])

    def step(self):

        # pick any waste present in the current cell
        if not self.carrying_waste_to_dispose:
            w = self.waste_nearby()
            if w is not None:
                self.pick_waste(w)

        # this loop needs to be separate in case the robot had picked-up waste
        if self.carrying_waste_to_dispose:
            self.move_to_disposal_site()
            if self.reached_disposal_site():
                self.depose_waste()
        else:
            self.move_randomly()

    def valid_positions(self, allow_robots=False):
        '''
        Look around neighboring tiles and return only those to which the
        robot can move to. This excludes tiles with tiles with radioactivity
        higher that what the robot can withstand, as well as tiles with robots
        already there (if allow_robots=True).
        '''

        positions = []
        nearby_cells = self.model.grid.get_neighborhood(self.pos, moore=True,
                                                        include_center=False)

        for pos in nearby_cells:

            # get the agent that corresponds to the radio zone
            # (by contruction, only one should exist)
            radio_agent = next(filter(
                lambda content: isinstance(content, RadioactiveZone),
                self.model.grid.get_cell_list_contents([pos])))
            # if valid position, add to the list
            if radio_agent.radio_level <= self.type + 1:
                positions.append(pos)

        if not allow_robots:

            # traverse the list backwards so as to safely "pop"
            for idx in reversed(range(len(positions))):

                pos = positions[idx]
                # get the agent that corresponds to the robot
                # (if present, only one should exist)
                robot_agent = list(filter(
                    lambda content: isinstance(content, Robot),
                    self.model.grid.get_cell_list_contents([pos])))

                if len(robot_agent) > 0:
                    del positions[idx]

        return positions

    def move(self, positions):
        '''Move to a randomly chosen tile amongst a list of positions'''

        if len(positions) > 0:
            new_pos = self.model.random.choice(positions)
            self.model.grid.move_agent(self, new_pos)

    def move_randomly(self):
        '''Random walker case, move to any valid position'''
        positions = self.valid_positions()
        if len(positions) > 0:
            self.move(positions)

    def direction_to_disposal_site(self, orientation=1):
        '''Get direction "vector" towards a goal:
        if orientation > 0: move to the next disposal site to drop a waste
        if orientation < 0: move to the previous disposal site to pick up waste
        '''
        if orientation > 0:
            if self.type < 2:
                # move to the east (towards the next zone)
                return dict(dx=1, dy=None)
            else:
                # move to the north-east (towards final disposal zone)
                return dict(dx=1, dy=1)
        else:
            # move to the west (towards the previous zone)
            return dict(dx=-1, dy=None)

    def move_to_disposal_site(self, orientation=1):
        # get valid positions and move if possible
        positions = list(filter(
            lambda pos: compare_positions(
                pos, self.pos, **self.direction_to_disposal_site(orientation)),
            self.valid_positions()
        ))
        self.move(positions)

    def reached_disposal_site(self, orientation=1) -> bool:
        # after moving, verify if there are any more "possible" valid moves
        # disregard robots, since they may move in the next steps
        positions = list(filter(
            lambda pos: compare_positions(
                pos, self.pos, **self.direction_to_disposal_site(orientation)),
            self.valid_positions(allow_robots=True)
        ))

        # True means that the disposal zone has been reached
        return len(positions) == 0

    def depose_waste(self):
        a = Waste(self.model.id, self, self.pos, type=self.type + 1)
        self.model.schedule.add(a)
        self.model.grid.place_agent(a, a.pos)
        self.model.id += 1

        self.carry = 0

    def waste_nearby(self) -> Union[None, Waste]:
        waste_contents = list(filter(
            lambda c: isinstance(c, Waste) and (c.type == self.type),
            self.model.grid.get_cell_list_contents([self.pos])
        ))
        if len(waste_contents) > 0:
            return waste_contents.pop()

    def pick_waste(self, waste_agent):
        self.model.grid.remove_agent(waste_agent)
        self.model.schedule.remove(waste_agent)
        self.carry += 1

    @property
    def carrying_waste_to_dispose(self) -> bool:
        return self.carry == 2


def sign(x):
    return 0 if x == 0 else (1 if x > 0 else -1)


def compare_positions(p0, p1, dx=None, dy=None):
    '''Helper function to filter out positions not in desired direction'''
    vx = False
    vy = False
    if dx is not None:
        vx = (sign(p0[0] - p1[0]) == sign(dx))
    if dy is not None:
        vy = (sign(p0[1] - p1[1]) == sign(dy))
    return vx or vy
